import json
import boto3
import uuid
import os
import random
from datetime import datetime, timedelta


dynamodb = boto3.client('dynamodb')

topicArn = os.getenv("TOPIC_NAME")
def makeUserAppointment( item ):
    response = dynamodb.put_item(
        TableName='users',
        Item = item
    )
    
    snsClient = boto3.client('sns')
    dictSubscriptionArn = snsClient.subscribe(
        TopicArn=topicArn,
        Protocol='email',
        Endpoint=item['email']['S'],
        ReturnSubscriptionArn=True
    )
        
    responseSns = snsClient.set_subscription_attributes(
        SubscriptionArn=dictSubscriptionArn['SubscriptionArn'],
        AttributeName='FilterPolicy',
        AttributeValue='{ \"email\": [ \"' + item['email']['S'] + '\" ] }'
    )

    return {
        'statusCode': 200,
        'body': json.dumps('Data added to DynamoDB table')
    }

def volunter( item ):
    response = dynamodb.put_item(
        TableName='volunters',
        Item = item
    )

    return {
        'statusCode': 200,
        'body': json.dumps('Data added to DynamoDB table')
    }

def deleteappointment(email, otp):
    if otp=='':
        snsClient = boto3.client('sns')
        
        generatedOtp = str(random.randint(100000, 999999))
        message = 'Your one-time code is: {}'.format(generatedOtp)
        
        expirationTime = datetime.now() + timedelta(minutes=5)
        expirationTimestamp = int(expirationTime.timestamp())

        item={
            'email': {'S': email},
            'otp': {'S': generatedOtp},
            'expirationTime': {'S': str(expirationTime)},
        }
        
        response = dynamodb.put_item(
            TableName='otp-table',
            Item = item
        )

        response = snsClient.publish(
            TopicArn=topicArn,
            Message= message,
            Subject='Foodbank : FoodforAll',
                MessageAttributes={
                    'email': {
                        'DataType': 'String',
                        'StringValue': email
                    }
            }
        )
        return { "statusCode" : 200 ,"message" : "OTP Sent"}
    else:
        response = dynamodb.get_item(
            TableName="otp-table",
            Key={
                'email': {'S': email}
            }
        )
        date_time = datetime.strptime(response['Item']['expirationTime']['S'], '%Y-%m-%d %H:%M:%S.%f')

        if 'Item' in response and date_time >= datetime.now():
            stored_otp = response['Item']['otp']['S']
            if stored_otp == otp:
                dynamodb.delete_item(
                    TableName="otp-table",
                    Key={
                        'email': {'S': email}
                    }
                )
                response = dynamodb.get_item(
                    TableName="users",
                    Key={
                        'email': {'S': email}
                    }
                )
                
                if 'Item' in response:
                    response  = dynamodb.delete_item(
                        TableName="users",
                        Key={
                            'email': {'S': email}
                        }
                    )
                    return { "statusCode" : 200 ,"message" : "Appoitment Deleted"}
                else:
                    return { "statusCode" : 404 ,"message" : "Appoitment Not found"}
            else:
                return { "statusCode" : 404 ,"message" : "OTP is invalid"}
        else:
            return { "statusCode" : 404 ,"message" : "OTP is expired or not found"}

        

def lambda_handler(event, context):
    if event['context']['http-method'] == 'POST' and event['context']['resource-path'] == '/makeappointment':
        name = event['body-json']['name']
        bannerID = event['body-json']['bannerID']
        email = event['body-json']['email']
        date = event['body-json']['date']
        item={
            'id': {'S': str(uuid.uuid4())},
            'name': {'S': name},
            'bannerID': {'S': bannerID},
            'email': {'S': email},
            'date': {'S': date},
        }
        return makeUserAppointment(item)
    elif event['context']['http-method'] == 'POST' and event['context']['resource-path'] == '/volunter':
        name = event['body-json']['name']
        hours = event['body-json']['hours']
        email = event['body-json']['email']
        date = event['body-json']['date']
        item={
            'id': {'S': str(uuid.uuid4())},
            'name': {'S': name},
            'email': {'S': email},
            'date': {'S': date},
            'hours': {'S': hours}
        }
        return volunter(item)
    elif event['context']['http-method'] == 'POST' and event['context']['resource-path'] == '/deleteappointment':
        email = event['body-json']['email']
        otp = event['body-json']['otp']
        return deleteappointment(email, otp)