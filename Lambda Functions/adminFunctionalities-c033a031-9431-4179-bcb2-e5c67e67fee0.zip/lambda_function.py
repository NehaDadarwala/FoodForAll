import json
import boto3
from datetime import datetime
from boto3.dynamodb.conditions import Key, Attr
import os

topicArn = os.getenv("TOPIC_NAME") 

def getData(table):
    startdate = datetime.today().strftime('%Y-%m-%d')

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(table)

    response = table.scan(
        FilterExpression=Attr("date").gte(str(startdate))
    )
    return {
            "statusCode" : "200",
            "Items" : response['Items']
    }
    
def publishMessage(message):
    snsClient = boto3.client('sns')
    
    response = snsClient.list_subscriptions_by_topic(TopicArn=topicArn)
    subscribers = response['Subscriptions']
    
    emails = []
    for subscriber in subscribers:
        email = subscriber['Endpoint']
        print("email", email)
        emails.append(email)
        
        snsClient.publish(
            TopicArn=topicArn,
            Message= message,
            Subject='Foodbank : FoodforAll',
                MessageAttributes={
                    'email': {
                        'DataType': 'String',
                        'StringValue': email
                    }
            }
        )
        
    return {"statusCode" : "200", "Emails: ": emails}


def lambda_handler(event, context):
    if event['context']['http-method'] == 'GET' and event['context']['resource-path'] == '/viewappointments':
        return getData("users")
    elif event['context']['http-method'] == 'GET' and event['context']['resource-path'] == '/viewvolunteers':
        return getData("volunters")
    elif event['context']['http-method'] == 'POST' and event['context']['resource-path'] == '/sendnotifications':
        return publishMessage(event['body-json']['message'])

        

