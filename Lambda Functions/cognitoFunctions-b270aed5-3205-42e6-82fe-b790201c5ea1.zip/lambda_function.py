import json
import os
import boto3

clientId = os.getenv('COGNITO_USER_CLIENT_ID') 
userPoolId = os.getenv('USER_POOL_ID')
region = os.getenv('COGNITO_REGION_NAME')

def change_password_challenge(username, password, session):

    cognito = boto3.client('cognito-idp')

    challenge_response = cognito.admin_respond_to_auth_challenge(
        UserPoolId=userPoolId,
        ClientId=clientId,
        ChallengeName='NEW_PASSWORD_REQUIRED',
        Session=session,
        ChallengeResponses={
            'USERNAME': username,
            'NEW_PASSWORD': password
        }
    )
    
    return challenge_response
    
def login (username, password):
    client = boto3.client("cognito-idp", region_name=region)

    
    response = client.initiate_auth(
        ClientId=clientId,
        AuthFlow="USER_PASSWORD_AUTH",
        AuthParameters={"USERNAME": username, "PASSWORD": password},
    )
    
    if 'ChallengeName' in response:
        # change_password_challenge(response, userPoolId, clientId, username, temp_password, new_password)
        return(response)
    else:
        access_token = response["AuthenticationResult"]["AccessToken"]
        response = client.get_user(AccessToken=access_token)
        return(response)
    

def lambda_handler(event, context):
    if event['context']['http-method'] == 'POST' and event['context']['resource-path'] == '/login':
        username = event['body-json']['email']
        password = event['body-json']['password']
        return login(username, password)
    elif event['context']['http-method'] == 'POST' and event['context']['resource-path'] == '/newPassword':
        username = event['body-json']['email']
        password = event['body-json']['password']
        session = event['body-json']['session']
        return change_password_challenge(username, password, session)